import React, { Component } from 'react';

class Footer extends Component {
    state = { };
    render() { 
        return <div className="footer">This is the footer</div>;
    }
}

export default Footer;